mkdir career-pathway-server
cd career-pathway-server
npm init -y
npm install express dotenv axios cors
