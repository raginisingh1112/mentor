import React from 'react';
import { Book, Star, Clock, Download } from 'lucide-react';

interface Course {
  id: number;
  title: string;
  instructor: string;
  price: number;
  rating: number;
  students: number;
  duration: string;
  image: string;
  category: string;
}

const courses: Course[] = [
  {
    id: 1,
    title: "Complete JEE Preparation 2024",
    instructor: "Dr. Amit Kumar",
    price: 2999,
    rating: 4.8,
    students: 15000,
    duration: "120 hours",
    image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-1.2.1&auto=format&fit=crop&w=1024&q=80",
    category: "Engineering"
  },
  {
    id: 2,
    title: "NEET Complete Course Bundle",
    instructor: "Dr. Priya Sharma",
    price: 3499,
    rating: 4.9,
    students: 12000,
    duration: "150 hours",
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1024&q=80",
    category: "Medical"
  },
  {
    id: 3,
    title: "Study Abroad Preparation Guide",
    instructor: "Sarah Williams",
    price: 1999,
    rating: 4.7,
    students: 8000,
    duration: "40 hours",
    image: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1024&q=80",
    category: "Study Abroad"
  }
];

const CourseShop: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Recommended Courses</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course) => (
          <div key={course.id} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
            <img
              src={course.image}
              alt={course.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <span className="inline-block px-3 py-1 text-sm font-medium text-indigo-600 bg-indigo-50 rounded-full mb-4">
                {course.category}
              </span>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{course.title}</h3>
              <p className="text-gray-600 mb-4">{course.instructor}</p>
              
              <div className="flex items-center mb-4">
                <Star className="w-5 h-5 text-yellow-400 fill-current" />
                <span className="ml-2 text-gray-700">{course.rating}</span>
                <span className="mx-2 text-gray-400">•</span>
                <span className="text-gray-600">{course.students.toLocaleString()} students</span>
              </div>
              
              <div className="flex items-center mb-4">
                <Clock className="w-5 h-5 text-gray-400" />
                <span className="ml-2 text-gray-600">{course.duration}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-gray-900">₹{course.price}</span>
                <button className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                  <Download className="w-5 h-5 mr-2" />
                  Enroll Now
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CourseShop;