import React from 'react';
import { Link } from 'react-router-dom';
import { MessageCircle, Phone, Video } from 'lucide-react';
import { Mentor } from '../types';
import VerifiedBadge from './common/VerifiedBadge';
import Rating from './common/Rating';

interface MentorCardProps {
  mentor: Mentor;
}

const MentorCard: React.FC<MentorCardProps> = ({ mentor }) => {
  return (
    <Link
      to={`/mentor/${mentor.id}`}
      className="block bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
    >
      <div className="p-4">
        <div className="flex items-start">
          <img
            src={mentor.image}
            alt={mentor.name}
            className="w-16 h-16 rounded-full object-cover"
          />
          <div className="ml-4 flex-1">
            <div className="flex items-center">
              <h3 className="text-lg font-semibold text-gray-900">
                {mentor.name}
              </h3>
              {mentor.verified && <VerifiedBadge size="sm" />}
            </div>
            <p className="text-sm text-gray-600">{mentor.expertise}</p>
            <p className="text-sm text-gray-500">{mentor.languages}</p>
            <div className="mt-2 flex items-center">
              <Rating value={mentor.rating} size="sm" />
              <span className="ml-2 text-sm text-gray-600">
                ({mentor.orders} sessions)
              </span>
            </div>
          </div>
          <div className="text-right">
            <p className="text-lg font-semibold text-indigo-600">
              ₹{mentor.price}/hr
            </p>
            <div className="mt-2 flex space-x-2">
              <button className="p-2 text-gray-600 hover:text-indigo-600">
                <MessageCircle className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-600 hover:text-indigo-600">
                <Phone className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-600 hover:text-indigo-600">
                <Video className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default MentorCard;