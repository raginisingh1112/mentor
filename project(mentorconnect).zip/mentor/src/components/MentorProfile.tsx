import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { MessageCircle, Phone, Video, Clock, Globe, Award, ArrowLeft } from 'lucide-react';
import { mentors } from '../data/mentors';
import VerifiedBadge from './common/VerifiedBadge';
import Rating from './common/Rating';

const MentorProfile: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const mentor = mentors.find(m => m.id === Number(id));

  if (!mentor) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-6 text-center">
        <h2 className="text-xl font-semibold text-gray-900">Mentor not found</h2>
        <Link to="/" className="text-indigo-600 hover:text-indigo-700 mt-4 inline-block">
          Return to mentor list
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6">
          <Link to="/" className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-6">
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to mentors
          </Link>

          <div className="flex items-start">
            <img
              src={mentor.image}
              alt={mentor.name}
              className="w-24 h-24 rounded-full object-cover"
            />
            <div className="ml-6">
              <div className="flex items-center">
                <h1 className="text-2xl font-bold text-gray-900">{mentor.name}</h1>
                {mentor.verified && <VerifiedBadge size="lg" />}
              </div>
              <p className="text-lg text-gray-600 mt-1">{mentor.expertise}</p>
              <div className="flex items-center mt-2">
                <Globe className="w-5 h-5 text-gray-500 mr-2" />
                <span className="text-gray-600">{mentor.languages}</span>
              </div>
              <div className="flex items-center mt-2">
                <Clock className="w-5 h-5 text-gray-500 mr-2" />
                <span className="text-gray-600">{mentor.experience}</span>
              </div>
              <div className="flex items-center mt-2">
                <Rating value={mentor.rating} size="md" />
                <span className="ml-2 text-gray-600">({mentor.orders} sessions)</span>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-2">About</h2>
            <p className="text-gray-700">{mentor.bio}</p>
          </div>

          <div className="mt-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-2">Achievements</h2>
            <ul className="space-y-2">
              {mentor.achievements?.map((achievement, index) => (
                <li key={index} className="flex items-center">
                  <Award className="w-5 h-5 text-indigo-600 mr-2" />
                  <span className="text-gray-700">{achievement}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-8 flex space-x-4">
            <a href="https://calendly.com/iabheejit" className="flex-1">
              <button className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center">
                <MessageCircle className="w-5 h-5 mr-2" />
                Chat (₹{mentor.price}/hr)
              </button>
            </a>
            <a href="https://calendly.com/roshni" className="flex-1">
              <button className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center">
                <Phone className="w-5 h-5 mr-2" />
                Call (₹{Math.round(mentor.price * 1.2)}/hr)
              </button>
            </a>
            <a href="https://calendly.com/iabheejit" className="flex-1">
              <button className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center">
                <Video className="w-5 h-5 mr-2" />
                Video (₹{Math.round(mentor.price * 1.5)}/hr)
              </button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MentorProfile;