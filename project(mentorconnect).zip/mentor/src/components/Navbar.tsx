import React from 'react';
import { Link } from 'react-router-dom';
import { Menu, MessageCircle, Home, Lightbulb } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Menu className="h-6 w-6 mr-4" />
            <Link to="/" className="text-xl font-bold text-indigo-600">MentorConnect</Link>
          </div>
          <div className="flex items-center space-x-4">
            <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
              ₹0 Balance
            </span>
            <MessageCircle className="h-6 w-6 text-gray-600" />
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;