import React, { useState, useEffect } from 'react';
import { Lightbulb, ArrowRight, Loader2, Rocket, ChevronDown } from 'lucide-react';
import { CareerGoal } from '../types';
import { careerPathways } from '../data/pathways';
import { generateCareerPathway } from '../lib/openai';

const AIPathway: React.FC = () => {
  const [selectedGoal, setSelectedGoal] = useState<CareerGoal | ''>('');
  const [customCareer, setCustomCareer] = useState('');
  const [pathway, setPathway] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showStartPage, setShowStartPage] = useState(true);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    if (fadeOut) {
      const timer = setTimeout(() => setShowStartPage(false), 500);
      return () => clearTimeout(timer);
    }
  }, [fadeOut]);

  const handleStartClick = () => {
    setFadeOut(true);
  };

  const handleGeneratePathway = async () => {
    setError(null);
    setIsLoading(true);
    
    try {
      if (selectedGoal) {
        setPathway(careerPathways[selectedGoal]);
      } else if (customCareer) {
        const generatedPathway = await generateCareerPathway(customCareer);
        setPathway(generatedPathway);
      }
    } catch (err) {
      setError('Failed to generate career pathway. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const formatPathway = (path: string): string[] => {
    if (!path) return [];
    return path.split('\n').filter(step => step.trim());
  };

  if (showStartPage) {
    return (
      <div className={`min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 to-indigo-900 transition-opacity duration-500 ${fadeOut ? 'opacity-0' : 'opacity-100'}`}>
        <div className="text-center px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl sm:text-6xl font-extrabold text-white mb-6 leading-tight">
            Discover Your <span className="text-yellow-400">Career Path</span>
          </h1>
          <p className="text-xl sm:text-2xl text-blue-200 mb-12 max-w-2xl mx-auto">
            Let AI guide you towards your dream career with personalized pathways and expert insights
          </p>
          <button
            onClick={handleStartClick}
            className="px-8 py-4 bg-yellow-400 text-blue-900 rounded-full text-xl font-semibold hover:bg-yellow-300 transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center mx-auto"
          >
            Get Started
            <Rocket className="ml-2 w-6 h-6" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-indigo-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-8">
            <div className="flex items-center">
              <Lightbulb className="w-10 h-10 text-yellow-400 mr-4" />
              <h2 className="text-3xl font-bold text-white">AI Career Pathway Generator</h2>
            </div>
          </div>
          <div className="p-8 space-y-8">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Choose a common career path
              </label>
              <div className="relative">
                <select
                  value={selectedGoal}
                  onChange={(e) => {
                    setSelectedGoal(e.target.value as CareerGoal);
                    setCustomCareer('');
                  }}
                  className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
                >
                  <option value="">Select a career path</option>
                  <option value="engineer">Become an Engineer</option>
                  <option value="doctor">Become a Doctor</option>
                  <option value="abroad">Study Abroad</option>
                </select>
                <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" />
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">OR</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Enter any career path
              </label>
              <input
                type="text"
                value={customCareer}
                onChange={(e) => {
                  setCustomCareer(e.target.value);
                  setSelectedGoal('');
                }}
                placeholder="e.g., Data Scientist, UI/UX Designer, etc."
                className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <button
              onClick={handleGeneratePathway}
              disabled={isLoading || (!selectedGoal && !customCareer)}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-4 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed font-semibold text-lg shadow-md"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-6 h-6 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  Generate Pathway
                  <ArrowRight className="ml-2 w-6 h-6" />
                </>
              )}
            </button>

            {error && (
              <div className="p-4 bg-red-100 border border-red-400 rounded-lg text-red-700">
                {error}
              </div>
            )}

            {pathway && (
              <div className="mt-8">
                <h3 className="text-2xl font-semibold text-gray-900 mb-6">
                  Your Personalized Pathway for {selectedGoal || customCareer}
                </h3>
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-6 shadow-inner">
                  {formatPathway(pathway).map((step, index) => (
                    <div key={index} className="flex items-start mb-6 last:mb-0">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex items-center justify-center flex-shrink-0 mt-0.5 font-bold text-lg shadow-md">
                        {index + 1}
                      </div>
                      <p className="ml-4 text-gray-700 text-lg">
                        {step.replace(/^\d+\.\s*/, '')}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIPathway;
