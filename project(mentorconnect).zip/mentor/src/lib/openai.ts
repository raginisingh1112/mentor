import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export const generateCareerPathway = async (career: string): Promise<string> => {
  try {
    const completion = await openai.chat.completions.create({
      messages: [
        {
          role: "system",
          content: "You are a career counselor helping students plan their career paths. Provide detailed, step-by-step guidance in a concise format."
        },
        {
          role: "user",
          content: `Create a detailed 7-step career pathway for becoming a ${career}. Include education requirements, skills needed, and timeline. Format each step with a number and brief description.`
        }
      ],
      model: "gpt-3.5-turbo",
    });

    return completion.choices[0].message.content || "Unable to generate pathway";
  } catch (error) {
    console.error('Error generating career pathway:', error);
    throw new Error('Failed to generate career pathway');
  }
};

export const generateAIResponse = async (question: string): Promise<string> => {
  try {
    const completion = await openai.chat.completions.create({
      messages: [
        {
          role: "system",
          content: "You are a helpful career counselor providing guidance to students about their career paths. Give specific, actionable advice."
        },
        {
          role: "user",
          content: question
        }
      ],
      model: "gpt-3.5-turbo",
    });

    return completion.choices[0].message.content || "I couldn't process your question. Please try again.";
  } catch (error) {
    console.error('Error generating AI response:', error);
    throw new Error('Failed to generate response');
  }
};