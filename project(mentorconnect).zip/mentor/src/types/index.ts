export interface Mentor {
  id: number;
  name: string;
  image: string;
  expertise: string;
  languages: string;
  experience: string;
  rating: number;
  orders: number;
  price: number;
  verified: boolean;
  bio?: string;
  achievements?: string[];
}

export interface PathwayData {
  engineer: string;
  doctor: string;
  abroad: string;
}

export type CareerGoal = keyof PathwayData;

export interface OpenAIResponse {
  choices: {
    message: {
      content: string;
    };
  }[];
}