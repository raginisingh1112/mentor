import { PathwayData } from '../types';

export const careerPathways: PathwayData = {
  engineer: `1. Focus on PCM in 11th & 12th (Score >90%)
2. Prepare for JEE/GATE
3. Join top engineering college
4. Build practical projects
5. Internships in 3rd year
6. Master specific domain
7. Join tech companies/startups`,
  
  doctor: `1. Focus on PCB in 11th & 12th (Score >90%)
2. NEET preparation
3. Join MBBS program
4. Complete internship
5. Choose specialization
6. Clear PG entrance
7. Complete residency`,
  
  abroad: `1. Maintain high academics (>85%)
2. Prepare for IELTS/TOEFL
3. Take SAT/GRE/GMAT
4. Build strong profile
5. Research universities
6. Apply for scholarships
7. Visa process`
};