import { Mentor } from '../types';

export const mentors: Mentor[] = [
  {
    id: 1,
    name: "Abheejit",
    image: "../src/components/1.png",
    expertise: "Startup & Business",
    languages: "English, Hindi",
    experience: "25+ Years",
    rating: 4.9,
    orders: 1205,
    price: 599,
    verified: true,
    bio: "Helping aspiring entrepreneurs build successful businesses.",
    achievements: [
      "Hackathon winner",
      
    ],
  },
  {
    id: 2,
    name: "Dr. Devi Shetty",
    image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    expertise: "Medical Career",
    languages: "English, Hindi, Kannada",
    experience: "40+ Years",
    rating: 4.8,
    orders: 890,
    price: 1499,
    verified: true,
    bio: "Founder of Narayana Health, pioneering affordable healthcare in India. Guiding aspiring medical professionals.",
    achievements: [
      "Padma Bhushan Awardee",
      "Founded Narayana Health",
      "Performed over 15,000 surgeries",
    ],
  },
  {
    id: 3,
    name: "Roshni Nadar",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80",
    expertise: "Tech & Leadership",
    languages: "English, Hindi",
    experience: "15+ Years",
    rating: 4.9,
    orders: 750,
    price: 1299,
    verified: true,
    bio: "Chairperson of HCL Technologies, passionate about technology and education. Mentoring future tech leaders.",
    achievements: [
      "Most Powerful Women in Business - Fortune India",
      "Leading India's largest IT services company",
      "Pioneer in CSR initiatives",
    ],
  }
];