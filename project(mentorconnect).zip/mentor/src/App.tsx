import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import MentorList from './components/MentorList';
import AIPathway from './components/AIPathway';
import MentorProfile from './components/MentorProfile';
import CourseShop from './components/CourseShop';
import AIChat from './components/AIChat';

const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <Routes>
          <Route path="/" element={
            <>
              <MentorList />
              <AIPathway />
              <AIChat />
              <CourseShop />
            </>
          } />
          <Route path="/mentor/:id" element={<MentorProfile />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;